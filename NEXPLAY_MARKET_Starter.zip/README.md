# NEXPLAY MARKET — starter project

A responsive Next.js starter storefront with a dark purple design and a Supabase database schema for a digital-goods marketplace.

## Important status

This is a **starter project**, not a live store. It does not accept real payments, does not issue products, and does not claim orders are delivered. Catalog cards are sample UI only. Payment providers intentionally fail closed until you implement official integrations and configure approved credentials.

## Requirements

- Node.js 20+
- A Supabase project
- A hosting account for Next.js (for example, Vercel)
- Adult/guardian help where a payment provider or merchant account requires it

## Run locally

1. Install Node.js 20 or newer.
2. Extract this folder and open a terminal inside it.
3. Run `npm install`.
4. Copy `.env.example` to `.env.local` and add your Supabase project URL and public anon key.
5. Run `npm run dev`.
6. Open `http://localhost:3000`.

The storefront UI can be viewed without configuring Supabase because the initial product cards are static design placeholders.

## Database

1. Create a Supabase project.
2. Open **SQL Editor**.
3. Run `supabase/schema.sql`.
4. Review RLS and add server-only API routes before allowing orders or admin actions.

The schema intentionally does not provide client write access to orders, payments, delivery, refunds, or admin logs. Those actions must be validated by server routes.

## Before launch

- Replace sample products with products you are authorized to sell.
- Configure real product variants and prices in integer minor units (e.g. centavos).
- Build authenticated server-side checkout and order routes.
- Implement verified provider webhooks using each provider's current official documentation.
- Verify provider, amount, currency, order reference, signature, and idempotency before marking payment verified.
- Use a durable queue and only fulfill after verified payment.
- Mark delivered only after delivery evidence is confirmed.
- Add role-based admin authorization, audit logs, rate limiting, abuse prevention, privacy/terms/refund policies, and monitoring.
- Never commit `.env.local` or service-role secrets.
- Test using provider sandbox/test mode first.

## Payment provider setup

Do not assume every provider offers a public API or that your account is eligible. Check official documentation and merchant onboarding for each provider. Provider adapters should remain disabled until configured. Never use fake endpoints or expose secret keys in frontend code.

## Discord

Once deployed, put the website URL in your Discord server's links, announcement, or shop channel. A website link does not automatically create a Discord bot. A bot integration can be added separately if you want order notifications or ticket support.
