-- NEXPLAY MARKET starter schema. Run in Supabase SQL Editor.
-- Keep service-role credentials on the server only. Review RLS policies before launch.
create extension if not exists pgcrypto;

create type public.order_status as enum (
  'PENDING_PAYMENT','PAID','PROCESSING','DELIVERED','DELIVERY_FAILED',
  'CANCELLED','REFUND_PENDING','REFUNDED','MANUAL_REVIEW'
);
create type public.payment_status as enum (
  'CREATED','AWAITING_PAYMENT','PENDING_VERIFICATION','VERIFIED',
  'FAILED','EXPIRED','REFUND_PENDING','REFUNDED'
);
create type public.fulfillment_mode as enum ('STOCKED','SUPPLIER','MANUAL');

create table public.profiles (
  id uuid primary key references auth.users(id) on delete cascade,
  display_name text,
  created_at timestamptz not null default now()
);

create table public.products (
  id uuid primary key default gen_random_uuid(),
  slug text unique not null,
  name text not null,
  description text not null default '',
  category text not null,
  image_url text,
  active boolean not null default false,
  fulfillment_mode public.fulfillment_mode not null default 'MANUAL',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.product_variants (
  id uuid primary key default gen_random_uuid(),
  product_id uuid not null references public.products(id) on delete cascade,
  sku text unique,
  name text not null,
  currency char(3) not null default 'PHP',
  price_minor bigint not null check (price_minor >= 0),
  active boolean not null default false,
  created_at timestamptz not null default now()
);

create table public.orders (
  id uuid primary key default gen_random_uuid(),
  order_number text unique not null,
  user_id uuid references auth.users(id) on delete set null,
  email text not null,
  currency char(3) not null,
  subtotal_minor bigint not null check (subtotal_minor >= 0),
  total_minor bigint not null check (total_minor >= 0),
  status public.order_status not null default 'PENDING_PAYMENT',
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.order_items (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  product_id uuid references public.products(id) on delete set null,
  variant_id uuid references public.product_variants(id) on delete set null,
  product_name_snapshot text not null,
  variant_name_snapshot text not null,
  unit_price_minor bigint not null check (unit_price_minor >= 0),
  quantity integer not null check (quantity > 0),
  line_total_minor bigint not null check (line_total_minor >= 0)
);

create table public.payments (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete restrict,
  provider text not null,
  provider_payment_id text,
  status public.payment_status not null default 'CREATED',
  currency char(3) not null,
  amount_minor bigint not null check (amount_minor >= 0),
  idempotency_key text unique not null,
  provider_reference text,
  verified_at timestamptz,
  created_at timestamptz not null default now(),
  unique(provider, provider_payment_id)
);

create table public.payment_events (
  id uuid primary key default gen_random_uuid(),
  provider text not null,
  event_id text not null,
  payment_id uuid references public.payments(id) on delete set null,
  event_type text not null,
  signature_valid boolean not null default false,
  payload jsonb not null default '{}'::jsonb,
  received_at timestamptz not null default now(),
  unique(provider, event_id)
);

create table public.fulfillment_jobs (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  status text not null default 'QUEUED' check (status in ('QUEUED','RUNNING','SUCCEEDED','FAILED','MANUAL_REVIEW')),
  attempts integer not null default 0,
  last_error text,
  created_at timestamptz not null default now(),
  updated_at timestamptz not null default now()
);

create table public.delivery_records (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete cascade,
  order_item_id uuid references public.order_items(id) on delete set null,
  delivery_method text not null check (delivery_method in ('AUTOMATIC','MANUAL')),
  status text not null check (status in ('PENDING','CONFIRMED','FAILED')),
  customer_message text,
  evidence_reference text,
  delivered_at timestamptz,
  created_at timestamptz not null default now()
);

create table public.refunds (
  id uuid primary key default gen_random_uuid(),
  order_id uuid not null references public.orders(id) on delete restrict,
  payment_id uuid references public.payments(id) on delete restrict,
  amount_minor bigint not null check (amount_minor >= 0),
  currency char(3) not null,
  status text not null default 'REQUESTED' check (status in ('REQUESTED','PENDING_PROVIDER','CONFIRMED','FAILED')),
  provider_refund_id text,
  created_at timestamptz not null default now()
);

create table public.admin_audit_logs (
  id uuid primary key default gen_random_uuid(),
  actor_id uuid references auth.users(id) on delete set null,
  action text not null,
  target_type text not null,
  target_id text,
  details jsonb not null default '{}'::jsonb,
  created_at timestamptz not null default now()
);

alter table public.profiles enable row level security;
alter table public.products enable row level security;
alter table public.product_variants enable row level security;
alter table public.orders enable row level security;
alter table public.order_items enable row level security;
alter table public.payments enable row level security;
alter table public.payment_events enable row level security;
alter table public.fulfillment_jobs enable row level security;
alter table public.delivery_records enable row level security;
alter table public.refunds enable row level security;
alter table public.admin_audit_logs enable row level security;

-- Safe public catalog read. Only explicitly active products/variants are public.
create policy "Public can read active products" on public.products
  for select using (active = true);
create policy "Public can read active variants" on public.product_variants
  for select using (
    active = true and exists (
      select 1 from public.products p where p.id = product_id and p.active = true
    )
  );

-- No client write policies are intentionally provided for orders/payments/delivery/admin.
-- Add server-side routes with authorization, validation, and service-role access.
-- Add admin role claims and policies before building the admin dashboard.
