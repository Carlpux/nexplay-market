import { ArrowUpRight, Gamepad2, ShieldCheck, Zap, Search, Sparkles, ShoppingBag, Headphones } from "lucide-react";

const categories = ["All products", "Gaming", "Discord", "Subscriptions", "Gift cards"];
const products = [
  { name: "Robux", category: "Gaming", desc: "Roblox credit options", price: "Choose an option", icon: "🎮", tag: "POPULAR" },
  { name: "Discord Nitro", category: "Discord", desc: "Official subscription options", price: "Choose an option", icon: "💜", tag: "DIGITAL" },
  { name: "Avatar Decorations", category: "Discord", desc: "Profile cosmetics & decorations", price: "Choose an option", icon: "✨", tag: "STYLE" },
  { name: "Discord Boosts", category: "Discord", desc: "Server boost options", price: "Choose an option", icon: "🚀", tag: "COMMUNITY" },
  { name: "Spotify", category: "Subscriptions", desc: "Available plans and offers", price: "Choose an option", icon: "🎧", tag: "MUSIC" },
  { name: "Digital Gift Cards", category: "Gift cards", desc: "Availability depends on region", price: "Coming soon", icon: "🎁", tag: "SOON" }
];

export default function Home() {
  return (
    <main>
      <nav className="nav wrap">
        <a className="brand" href="#"><span className="brand-mark"><Gamepad2 size={21}/></span><span>NEXPLAY<span className="brand-accent"> MARKET</span></span></a>
        <div className="nav-links"><a href="#products">Products</a><a href="#how">How it works</a><a href="#support">Support</a></div>
        <a className="cart-button" href="#products"><ShoppingBag size={17}/> Browse <ArrowUpRight size={15}/></a>
      </nav>

      <section className="hero wrap">
        <div className="hero-copy">
          <div className="eyebrow"><span className="live-dot"/> DIGITAL GOODS, MADE SIMPLE</div>
          <h1>Your next digital<br/>upgrade <span>starts here.</span></h1>
          <p className="hero-desc">Gaming essentials, Discord services, and digital goodies — all in one place. Clear options, straightforward checkout, and order support when you need it.</p>
          <div className="hero-actions"><a className="primary-button" href="#products">Explore products <ArrowUpRight size={17}/></a><a className="text-button" href="#how">How it works <span>↗</span></a></div>
          <div className="trust-row"><div className="trust-item"><ShieldCheck size={16}/> Secure checkout setup</div><div className="trust-item"><Zap size={16}/> Digital delivery</div></div>
        </div>
        <div className="hero-art">
          <div className="orbit orbit-one"></div><div className="orbit orbit-two"></div>
          <div className="floating-card card-top"><span className="mini-icon">✦</span><div><b>Digital collection</b><small>Built for your setup</small></div><span className="status-dot"/></div>
          <div className="main-cube"><div className="cube-glow"></div><Gamepad2 size={96} strokeWidth={1.2}/><span>N+</span></div>
          <div className="floating-card card-bottom"><span className="success-icon">✓</span><div><b>Order tracking</b><small>Updates as your order moves</small></div></div>
          <div className="spark spark-a">✦</div><div className="spark spark-b">✧</div>
        </div>
      </section>

      <section className="benefits wrap">
        <div className="benefit"><ShieldCheck/><div><b>Clear order status</b><span>Know where your order stands</span></div></div>
        <div className="benefit"><Zap/><div><b>Digital-first</b><span>Made for online products</span></div></div>
        <div className="benefit"><Headphones/><div><b>Support when needed</b><span>Help for order questions</span></div></div>
      </section>

      <section id="products" className="products-section wrap">
        <div className="section-heading"><div><div className="eyebrow">THE MARKETPLACE</div><h2>Find your next <span>upgrade.</span></h2><p>Browse the collection. Product availability and final prices will be shown once configured by the store admin.</p></div><div className="search-box"><Search size={17}/><span>Search products</span><kbd>⌕</kbd></div></div>
        <div className="category-row">{categories.map((c,i)=><button className={i===0?"category active":"category"} key={c}>{c}</button>)}</div>
        <div className="product-grid">{products.map((p,i)=><article className="product-card" key={p.name}>
          <div className={`product-art art-${i}`}><span className="product-tag">{p.tag}</span><span className="product-emoji">{p.icon}</span><div className="art-ring"></div></div>
          <div className="product-info"><div className="product-category">{p.category}</div><h3>{p.name}</h3><p>{p.desc}</p><div className="product-bottom"><span className="price">{p.price}</span><button className="add-button" aria-label={`View ${p.name}`} onClick={undefined}>↗</button></div></div>
        </article>)}</div>
        <div className="notice"><Sparkles size={17}/><p><b>Store setup in progress.</b> These are starter catalog examples, not live offers. Real prices, stock, payment methods, and delivery will only activate after configuration and verification.</p></div>
      </section>

      <section id="how" className="how-section"><div className="wrap how-inner"><div><div className="eyebrow">SIMPLE BY DESIGN</div><h2>From checkout<br/>to <span>delivery.</span></h2><p>Orders should move forward only after payment is verified. Digital items are marked delivered only when delivery is confirmed.</p></div><div className="steps"><div className="step"><span>01</span><div><b>Choose a product</b><p>Review the available options and product details.</p></div></div><div className="step"><span>02</span><div><b>Pay securely</b><p>Use a payment method enabled by the store.</p></div></div><div className="step"><span>03</span><div><b>Track your order</b><p>See verified payment and delivery status.</p></div></div></div></div></section>

      <footer id="support" className="footer wrap"><a className="brand" href="#"><span className="brand-mark"><Gamepad2 size={19}/></span><span>NEXPLAY<span className="brand-accent"> MARKET</span></span></a><span>Digital goods, made simple.</span><a href="mailto:support@example.com">Support contact — configure before launch</a><small>© {new Date().getFullYear()} NEXPLAY MARKET. Product names belong to their respective owners.</small></footer>
    </main>
  );
}
