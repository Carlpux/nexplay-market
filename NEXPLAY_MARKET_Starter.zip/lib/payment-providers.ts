/**
 * Provider contract only — no payment provider is enabled in this starter.
 * Implement only against official provider documentation and approved merchant credentials.
 */
export type CurrencyCode = string;

export type PaymentRequest = {
  orderId: string;
  orderNumber: string;
  amountMinor: number;
  currency: CurrencyCode;
  customerEmail: string;
  idempotencyKey: string;
};

export type PaymentSession = {
  providerPaymentId: string;
  checkoutUrl: string;
};

export type VerifiedPayment = {
  providerPaymentId: string;
  orderNumber: string;
  amountMinor: number;
  currency: CurrencyCode;
  paid: boolean;
};

export interface PaymentProvider {
  readonly name: string;
  createPayment(request: PaymentRequest): Promise<PaymentSession>;
  verifyWebhook(rawBody: string, headers: Headers): Promise<VerifiedPayment>;
}

/**
 * Fail closed by default. Do not mark an order paid based on a browser redirect,
 * uploaded screenshot, or client-provided "success" flag.
 */
export function getPaymentProvider(_providerName: string): PaymentProvider {
  throw new Error("Payment provider is not configured. Complete official onboarding and server-side verification first.");
}
